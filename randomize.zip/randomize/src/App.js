import React, { Component } from 'react';
import logo from './logo.png';
import dropdownMenu from './dropdown.png';
import './App.css';
import { Button } from 'react-bootstrap';
import random_logo from './random_logo.png';
import Application from './map.js';

class App extends Component {
	render() {
		return (
			<div className="App">
					<header className="App-header">
						<div className="clogo">
								<img src={logo} className="logopic" /> 
							</div>
		
						<div class="dropdown show" className="cdropdown">
						<a class="btn btn-danger dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" className="dropdown">
							<img src={dropdownMenu} className="dropdownpic" /> 
						</a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="#">Log-in</a>
							<a class="dropdown-item" href="#">Sign-up</a>
							<a class="dropdown-item" href="#">View all Restaurants</a>
						</div>
					</div>
					</header>

					<div id="randomizeButton" >
					  <Button variant="danger" className="logopic"> Randomize </Button>
					</div>

					<div id = "checkbox-container" type = "container"> 
						<div type = "checkbox" id="Left-checkbox" >
							<div id = "price-range-container"> 
								<div id = "filter-text"> Price Range </div>
								
								<button className = "price-range-buttons"  id = "firstbutton" > 0 - 50 php </button>
								<button className = "price-range-buttons"  id = "secondbutton" > 51-100 php </button>
								<button className = "price-range-buttons" id = "thirdbutton" > 101 - 250 php </button>
								<button className = "price-range-buttons"  id = "fourthbutton" > 251 - 500 php </button>
								<button className = "price-range-buttons" id = "fifthbutton" > 500+ php </button>

							</div>
						</div>
					</div>


					<div id = "map-container" type = "container" className="logopic"> 
						
						<div id = "thumbnail">
							
						</div>

						<div id = "mapThumb">
							<Application/>
						</div>

					</div>

				</div>
		);
	}
}

export default App;
